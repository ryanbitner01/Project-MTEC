//
//  ViewController.swift
//  Lab - Display Data
//
//  Created by Ryan Bitner on 2/2/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

