//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by Ryan Bitner on 2/8/21.
//

import SwiftUI

@main
struct LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
