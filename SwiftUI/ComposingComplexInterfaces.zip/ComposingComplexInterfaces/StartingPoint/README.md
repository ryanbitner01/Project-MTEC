# Completed Project: Animating Views and Transitions

Explore the completed project for the [Animating Views and Transitions](https://developer.apple.com/tutorials/swiftui/animating-views-and-transitions) tutorial.