//
//  TestingArchitectureApp.swift
//  TestingArchitecture
//
//  Created by Ryan Bitner on 9/16/21.
//

import SwiftUI

@main
struct TestingArchitectureApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
